import ImageViewer from './src/image-viewer.component'
import {PropsDefine as ImageViewerPropsDefine} from './src/image-viewer.type'

export {ImageViewer, ImageViewerPropsDefine}
export default ImageViewer