export default {
    golfnews : {
        ic_golfnews_choosen : require('../../Images/golfnews/ic_golfnews_choosen.png'),
        ic_golfnews_gray : require('../../Images/golfnews/ic_golfnews_gray.png'),
        ic_back : require('../../Images/golfnews/ic_back.png'),
        ic_television : require('../../Images/golfnews/ic_television.png'),
        ic_video : require('../../Images/golfnews/ic_video.png'),
        ic_navigator : require('../../Images/golfnews/ic_navigator.png'),
        ic_search : require('../../Images/golfnews/ic_search.png'),

        ic_alert : require('../../Images/golfnews/ic_alert.png'),
        ic_gop_y : require('../../Images/golfnews/ic_gop_y.png'),
        ic_introduct : require('../../Images/golfnews/ic_introduct.png'),
        ic_vote_golfer : require('../../Images/golfnews/vote_golfer.png'),
        notification_off : require('../../Images/golfnews/notification_off.png'),
        notification_on : require('../../Images/golfnews/notification_on.png'),
        ic_play_video : require('../../Images/golfnews/ic_play_video.png'),
        ic_copy : require('../../Images/golfnews/ic_copy.png'),
        ic_share : require('../../Images/golfnews/ic_share.png'),
        ic_quit : require('../../Images/golfnews/ic_quit.png'),
        ic_clear : require('../../Images/golfnews/ic_clear.png')
    }
    // audio: {
    //     hit: require('./assets/audio/hit.mp3'),
    //     point: require('./assets/audio/point.mp3'),
    //     wing: require('./assets/audio/wing.mp3'),
    // },
};
